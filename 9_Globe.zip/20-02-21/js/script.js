$('.course').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    smartSpeed:2000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
})

$(document).ready(function(){
$('.partners').owlCarousel({
    rtl:true,
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
})

$('.owl-prev').html('<i class="fas fa-arrow-right"></i>')
$('.owl-next').html('<i class="fas fa-arrow-left"></i>')
});