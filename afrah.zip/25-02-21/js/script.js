
$(document).ready(function(){
$('.jalabiya_owl').owlCarousel({
    
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
})

$('.owl-prev').html('<i class="fas fa-caret-right"></i>')
$('.owl-next').html('<i class="fas fa-caret-left"></i>')
});

$(document).ready(function(){
    $('.hijab_owl').owlCarousel({
        rtl:true,
        loop:true,
        margin:10,
        nav:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:3
            }
        }
    })
    
    $('.owl-prev').html('<i class="fas fa-caret-right"></i>')
    $('.owl-next').html('<i class="fas fa-caret-left"></i>')
    });

    $(document).ready(function(){
        $('.night_owl').owlCarousel({
            rtl:true,
            loop:true,
            margin:10,
            nav:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        })
        
        $('.owl-prev').html('<i class="fas fa-caret-right"></i>')
        $('.owl-next').html('<i class="fas fa-caret-left"></i>')
        });

        $(document).ready(function(){
            $('.night_owl1').owlCarousel({
                rtl:true,
                loop:true,
                margin:10,
                nav:true,
                responsive:{
                    0:{
                        items:1
                    },
                    600:{
                        items:2
                    },
                    1000:{
                        items:3
                    }
                }
            })
            
            $('.owl-prev').html('<i class="fas fa-caret-right"></i>')
            $('.owl-next').html('<i class="fas fa-caret-left"></i>')
            });

        